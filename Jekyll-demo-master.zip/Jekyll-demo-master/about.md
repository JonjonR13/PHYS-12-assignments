---
layout: default
title: About
permalink: /about/
---

This is my edited webpage for PHYS-S12: Introduction to Digital Fabrication

